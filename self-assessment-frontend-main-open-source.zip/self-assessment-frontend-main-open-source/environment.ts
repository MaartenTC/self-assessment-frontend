
export const environment = {
    baseUrl : "http://localhost:8080",
    csrfToken : "",
    minRisk : 0,
    maxRisk : 100,
    maxTextSize : 500
}