# Self-Assessment-Frontend
Deze repo bevat de frontend voor https://github.com/Alliander/self-assessment

## Angular downloaden
Om de frontend te runnen met de angular CLI, moet hiervoor de volgende npm installatie gedaan worden.
```
npm install -g @angular/cli
```
Bij een oude versie van Node.js kan deze error verschijnen:
```
The Angular CLI requires a minimum Node.js version of v20.19 or v22.12.
```
Ga dan naar **https://nodejs.org/en/download** en download een nieuwe versie, of gebruik Node Version Manager **https://github.com/nvm-sh/nvm** 

## License
This project is licensed under the Apache License Version 2.0 - see licence for details.



