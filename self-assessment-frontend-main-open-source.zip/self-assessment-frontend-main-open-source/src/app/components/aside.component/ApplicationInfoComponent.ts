import { Component, EventEmitter, inject, Input, OnChanges, Output, ViewChild } from '@angular/core';
import { ApplicationDTO } from '../../dto/ApplicationDTO';
import { ApplicationFormComponent } from "../global.component/applicationForm";
import { FormGroup } from '@angular/forms';
import { ApplicationType } from '../../enums/ApplicationType';
import { LifecyclePhase } from '../../enums/LifecyclePhase';
import { ProgrammingLanguage } from '../../enums/ProgrammingLanguage';
import { DeploymentType } from '../../enums/DeploymentType';
import { AssessmentService } from '../../service/AssessmentService';

@Component({
  selector: 'application-info-component',
  template: `
        <div class="application-info-container" [class.hidden]="!active">
          <div class="header-row">
            <button class="toggleButton" (click)="toggleActive()">{{icon}}</button>
            <h2 [class.hidden]="!active">Application Info</h2>
          </div>
          <div class="collapsible-container" [class.hidden]="!active">
              <application-form (submit)="updateApplicationContext()"></application-form>
          </div> 
        </div> 

  `,

  styles: `
  .header-row {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  h2.hidden {
    display: none;
  }
  .application-info-container {
    float: right;
    border-left: 1px solid gray;
    height: 100vh;
    width: 100%;
    
  }
  .toggleButton {
    cursor: pointer;
    background-color: white;
    border-color: blue;
    margin: 5px;
    border-radius: 50%;
    width: 30px;
    height: 30px;
  }
  .collapsible-container.hidden {
    display: none;
    width: 0%;
  }
  .collapsible-container {
    padding-left: 5%;
    padding-right: 5%;
    overflow-x: hidden;
  }`,
  imports: [ApplicationFormComponent]
  
})
export class ApplicationInfo implements OnChanges{
  /**
   * gebruik het applicationId dat is meegekomen met de geselecteerde assessment om de ApplicationDTO op te halen
   */
  active : boolean = true;
  icon : string = '▲';
  @Input() currentApplicationId : string = '';	
  @ViewChild(ApplicationFormComponent) applicationFormComponent!: ApplicationFormComponent;
  @Output() componentActiveEvent = new EventEmitter<boolean>();
  assessmentService : AssessmentService = inject(AssessmentService);
  application : ApplicationDTO ={
    applicationId: 'placeholder',
    name: 'placeholder',
    type: null,
    lifecyclePhase: null,
    systemSize: null,
    deploymentType: null,
    language: null
  }

  ngOnChanges(): void {
      this.assessmentService.fetchApplication(this.currentApplicationId)
      .then( response => response.json())
      .then( (application : ApplicationDTO) => {
          this.application = application;
          this.loadForm(this.application);
      })
  }
  toggleActive() : void {
    this.active = !this.active;
    if (this.active) {
      this.icon = '▲';
    }
    else {
      this.icon = '▼';
    }
    this.componentActiveEvent.emit(this.active);
  }
  loadForm(application : ApplicationDTO) : void {
    this.applicationFormComponent.applicationFormGroup.patchValue({
      applicationId: application.applicationId,
      name: application.name,
      type: application.type,
      lifecyclePhase: application.lifecyclePhase,
      systemSize: application.systemSize,
      deploymentType: application.deploymentType,
      language: application.language
    }); 
    this.applicationFormComponent.disableNotAllowedFields();

  }

  updateApplicationContext() : void {
    const formGroup : FormGroup = this.applicationFormComponent.applicationFormGroup;
    const applicationDTO : ApplicationDTO = {
      applicationId: formGroup.getRawValue().applicationId,
      name: formGroup.getRawValue().name,
      systemSize: formGroup.getRawValue().systemSize,
      type: formGroup.getRawValue().type as ApplicationType,
      lifecyclePhase: formGroup.getRawValue().lifecyclePhase as LifecyclePhase,
      language: formGroup.getRawValue().language as ProgrammingLanguage,
      deploymentType: formGroup.getRawValue().deploymentType as DeploymentType
    }
    this.assessmentService.updateApplicationContext(applicationDTO).then(response => {
            if (response.ok) {
                this.applicationFormComponent.showSuccess();
            } else {
                this.applicationFormComponent.showFailed();
            }
    }).catch(() => this.applicationFormComponent.showFailed());;
    
  }
}