export interface CorrectionDTO {
        correctionComment : string;
        newRisk : number; 
}