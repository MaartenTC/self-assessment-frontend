export interface FindingDTO {
        findingId : number,
        normId : number;
        text : string;
        risk : number;
}