export enum DeploymentType {
  CLOUD = "CLOUD",
  ON_PREMISE = "ON_PREMISE",
  HYBRID = "HYBRID"
}
