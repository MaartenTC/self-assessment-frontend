export enum ProgrammingLanguage {
  JAVA = "JAVA",
  PYTHON = "PYTHON",
  TYPESCRIPT = "TYPESCRIPT",
  CSHARP = "CSHARP",
  JAVASCRIPT = "JAVASCRIPT",
  POWERSHELL = "POWERSHELL",
  GO = "GO",
  KOTLIN = "KOTLIN",
  SQL = "SQL",
  R = "R",
  MAGIK = "MAGIK",
  FSHARP = "FSHARP",
  CPP = "CPP"
}
